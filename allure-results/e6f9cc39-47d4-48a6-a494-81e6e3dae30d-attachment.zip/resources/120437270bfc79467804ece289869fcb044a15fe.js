$(() => {
  //default styles
  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/user"
  ) {
    $(".dashboardImgDiv").css("background-color", "#44d09f");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/homeActive.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
  }

  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/user/dashboard/"
  ) {
    $(".dashboardImgDiv").css("background-color", "#44d09f");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/homeActive.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
  }

  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/squad"
  ) {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#44d09f");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squadActive.svg");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
  }

  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/squad/chat"
  ) {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#44d09f");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messagingActive.svg");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
  }

  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/user/gifting"
  ) {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#44d09f");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/giftingActive.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
  }

  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/user/sendgift"
  ) {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#44d09f");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/giftingActive.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
  }

  if (
    window.location.href ==
    window.location.protocol + "//" + window.location.host + "/user/profile"
  ) {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#44d09f");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profileActive.png");
  }

  $("#dashboardSidenav").click(() => {
    $(".dashboardImgDiv").css("background-color", "#44d09f");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/homeActive.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");

    window.location.href =
      window.location.protocol +
      "//" +
      window.location.host +
      "/user/dashboard";
  });

  $("#squadsSidenav").click(() => {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#44d09f");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squadActive.svg");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");

    window.location.href =
      window.location.protocol + "//" + window.location.host + "/squad";
  });

  $("#messagingSidenav").click(() => {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#44d09f");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messagingActive.svg");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");
    window.location.href =
      window.location.protocol + "//" + window.location.host + "/squad/chat";
  });

  $("#giftingSidenav").click(() => {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#44d09f");
    $(".profileImgDiv").css("background-color", "#d9f5eb");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/giftingActive.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profile.png");

    window.location.href =
      window.location.protocol + "//" + window.location.host + "/user/gifting";
  });

  $("#profileSidenav").click(() => {
    $(".dashboardImgDiv").css("background-color", "#d9f5eb");
    $(".squadsImgDiv").css("background-color", "#d9f5eb");
    $(".messageImgDiv").css("background-color", "#d9f5eb");
    $(".giftingImgDiv").css("background-color", "#d9f5eb");
    $(".profileImgDiv").css("background-color", "#44d09f");

    $("#imgDash").attr("src", "/assets/icons/navigation/home.png");
    $("#imgSquad").attr("src", "/assets/icons/navigation/squad.png");
    $("#imgMsg").attr("src", "/assets/icons/navigation/messaging.png");
    $("#imgGift").attr("src", "/assets/icons/navigation/gift.png");
    $("#imgProfile").attr("src", "/assets/icons/navigation/profileActive.png");

    window.location.href =
      window.location.protocol + "//" + window.location.host + "/user/profile";
  });

  $("#logoutSidenav").click(() => {
    window.location.href =
      window.location.protocol + "//" + window.location.host + "/user/logout";
  });

  $("#logoutTogglenav").click(() => {
    window.location.href =
      window.location.protocol + "//" + window.location.host + "/user/logout";
  });
});
