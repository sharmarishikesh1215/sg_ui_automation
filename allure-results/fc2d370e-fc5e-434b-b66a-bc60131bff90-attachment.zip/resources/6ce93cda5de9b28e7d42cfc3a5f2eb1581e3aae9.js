
$(function () {
    var telInput = $("#phone_number,#txtPhone");

    // initialise plugin
    var iti = telInput.intlTelInput({

        allowExtensions: true,
        formatOnDisplay: true,
        autoFormat: true,
        autoHideDialCode: true,
        autoPlaceholder: true,
        defaultCountry: "auto",
        ipinfoToken: "yolo",

        nationalMode: false,
        numberType: "MOBILE",
        //onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
        preferredCountries: ['gb', 'ae', 'us', 'ca', 'in'],
        preventInvalidNumbers: true,
        separateDialCode: true,
        initialCountry: "auto",
        geoIpLookup: function (callback) {
            if (!$('#country_code').val()) {
            window.navigator.geolocation.getCurrentPosition((data)=>{
                console.log(data["coords"]["latitude"]);
                $.get(`/getLocation/${data["coords"]["latitude"]}/${data["coords"]["longitude"]}`,(data,status)=>{
                    callback(data[0]["countryCode"]);
                });

            }, console.log);
            
            }
        },
        utilsScript: "/vendor/location/utils.js"
    });

    if ($('#country_code').val()) {
        const country_code = $('#country_code').val()
        const phone_number = $('#phone_number').val()
        telInput.intlTelInput("setNumber", `${country_code}${phone_number}`)

        $('#phone_number').val($('#phone_number').val().replace(/ /g,''));
    }

    var reset = function () {
        telInput.removeClass("error");
    };

    // on blur: validate
    telInput.blur(function () {
        reset();
        if ($.trim(telInput.val())) {
            if (!telInput.intlTelInput("isValidNumber")) {
                telInput.addClass("error");
            }
        }
    });

    telInput.on("countrychange", function() {
        // do something with iti.getSelectedCountryData()
        $("#country_code").val(`+${$("#phone_number").intlTelInput("getSelectedCountryData").dialCode}`);
      });

    // on keyup / change flag: reset
    telInput.on("keyup change", reset);
});
