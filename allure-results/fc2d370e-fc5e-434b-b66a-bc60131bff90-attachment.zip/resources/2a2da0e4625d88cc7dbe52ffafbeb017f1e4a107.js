$(async function () {
  var firebaseConfig = firebase_configuration;
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

  const FieldValue = firebase.firestore.FieldValue;

  // A reference to the database service
  var db = firebase.firestore();

  let loggedInUser = null;
  let notificationCount = 0;
  let modifyFlag = false;
  let pendingExist = true;

  const readAllNotifications = async (email) => {
    try {
      const unreadUserNotifications = await db
        .collection("users")
        .doc(email)
        .collection("notifications")
        .where("read_timestamp", "==", null)
        .get();
      if (unreadUserNotifications.empty) return;
      for (const doc of unreadUserNotifications.docs) {
        if (doc && doc.id) {
          await db
            .collection("users")
            .doc(email)
            .collection("notifications")
            .doc(doc.id)
            .update({ read_timestamp: firebase.firestore.Timestamp.now() });
        }
      }
      pendingExist = false;
    } catch (error) {
      console.log(error);
    }
  };

  const getloggedInUser = async () => {
    await axios
      .get(
        window.location.protocol +
          "//" +
          window.location.host +
          "/user/dashboard/loggedInDetails"
      )
      .then(async (info) => {
        loggedInUser = info.data;
        try {
          const unreadUserNotifications = await db
            .collection("users")
            .doc(loggedInUser.email)
            .collection("notifications")
            .where("read_timestamp", "==", null)
            .get();
          if (unreadUserNotifications.empty) return;
          for (const doc of unreadUserNotifications.docs) {
            if (doc && doc.id) {
              const notification = doc.data();
              const type = notification.type;
              const body = notification.body;
              const title = notification.title.toLowerCase();
              const quantity = notification.quantity;
              const message = notification.message;
              const receiverEmail = notification.receiverEmail;
              const receiverName = notification.receiverName;
              const senderEmail = notification.senderEmail;
              const senderName = notification.senderName;
              let target = false;
              if (
                notification.token &&
                notification.token.length &&
                type == "gift"
              ) {
                link = "/user/gifting/#my_gifts";
                const card =
                notification.card && notification.card.length
                ? notification.card.includes("http")
                ? notification.card
                : api_url + notification.card
                : "";
                const sentDate = new Date(notification.timestamp.seconds * 1000).toLocaleDateString()
                let redirect = `/user/gifting/giftreceived/?quantity=${quantity}&card=${card}&message=${message.replace(/#/g, "hashhash")}&senderEmail=${senderEmail}&senderName=${senderName}&receiverEmail=${receiverEmail}&receiverName=${receiverName}`
                if (notification.isSender) {
                  redirect = `/user/gifting/giftsent/?gift=sent&name=${receiverName}&email=${receiverEmail}&date=${sentDate}`
                }
                // add modal html here
                $("#globalModal").html(`
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background: url(/assets/img/GiftingPage/giftModalBg.png); border-radius: 22px; background-size: 100% 100%;">
                    <div class="modal-body">
                    <!-- <button class="modal-close" data-dismiss="modal">&times;</button> -->
                      <div class="text-center">
                        <img src="/assets/img/GiftingPage/giftCardModal.png" alt="" style="max-width:222px; height:auto">
                        <div class="pt-2 pb-4">
                          <p style="
                          font-family: 'Montserrat';
                          font-style: normal;
                          font-weight: 700;
                          font-size: 26px;
                          line-height: 40px;
                          /* or 154% */
                          

                          text-align: center;

                          color: #FFFFFF;" class="mb-0">${body}</p>
                            ${
                              card && card.length
                                ? `<img class="img-fluid my-3" src="${card}" alt="" style="max-width: 265px; width:auto; height: auto">`
                                : ""
                            }

                            <p style="
                            font-family: 'Montserrat';
                            font-style: normal;
                            font-weight: 500;
                            font-size: 24px;
                            line-height: 29px;
                            text-align: center;
                            
                            color: #FFFFFF;" class="py-1">${message}</p>

                            <a href="${redirect}"
                            style="color: white; background: #03313E; width: 140px; text-align: center; border-radius: 5px; font-size: 14px; font-weight: 600;"
                              type="button"
                              data-index="0"
                              class="
                                download-gift-btn
                                btn btn-block
                                my-2
                                mx-auto
                                rounded
                                shadow-sm
                                formButton
                              "
                              style="color: #FFFFFF;"
                            >
                              Open Gift
                            </a>

                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              `);
                $("#globalModal").modal("show");
                await db
                  .collection("users")
                  .doc(loggedInUser.email)
                  .collection("notifications")
                  .doc(doc.id)
                  .update({
                    read_timestamp: firebase.firestore.Timestamp.now(),
                  });
                break;
              }
            }
          }
        } catch (error) {
          console.log(error);
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  await getloggedInUser();

  if (loggedInUser) {
    const userEmail = loggedInUser.email;
    try {
      await db
        .collection("users")
        .doc(userEmail)
        .collection("notifications")
        .onSnapshot((querySnapshot) => {
          querySnapshot.docChanges().forEach((change) => {
            // on getting new notification
            //on receiving new notification set pendingExists = true and update notification counter
            if (change.type === "added") {
              if (!change.doc.data().read_timestamp) {
                // console.log(change.doc.data());
                pendingExist = true;
                notificationCount++;
                $("#notifications-counter").html(` ${notificationCount} `);
              }
            }

            // on getting new notification change.type === "modified" also gets triggered
            if (change.type === "modified") {
              // if modifyFlag = true, then existing notification is modified. else new notification is created.
              if (!modifyFlag) {
                const notification = change.doc.data();
                let date = new Date(notification.timestamp.seconds * 1000)
                  .toString()
                  .split(" ")
                  .slice(0, 4)
                  .join(" ");
                let link;
                const type = notification.type;
                const body = notification.body;
                const title = notification.title.toLowerCase();
                const quantity = notification.quantity;
                const message = notification.message;
                const receiverEmail = notification.receiverEmail;
                const receiverName = notification.receiverName;
                const senderEmail = notification.senderEmail;
                const senderName = notification.senderName;
                const card = notification.card
                let target = false;
                const isSender = notification.isSender;
                // let hrefLink;
                // if(isSender==false){
                //   hrefLink = `/user/gifting/giftreceived/?quantity=${quantity}&card=${card}&message=${message}&senderEmail=${senderEmail}&senderName=${senderName}&receiverEmail=${receiverEmail}&receiverName=${receiverName}`
                // }else{
                //   console.log("Hi")
                //   hrefLink = `/user/gifting/giftsent?gift=sent&name=${receiverName}&email=${receiverEmail}&date=${sentDate}`
                //   try{
                //    await db.collection("users").doc(userEmail).onSnapshot((DataSnapshot)=>{console.log(DataSnapshot)})
                //   }catch(err){console.log(err)}
                // }
                // console.log(hrefLink)
                if (
                  notification.token &&
                  notification.token.length &&
                  type == "gift"
                ) {
                  link = "/user/gifting/#my_gifts";
                  const card =
                  notification.card && notification.card.length
                  ? notification.card.includes("http")
                  ? notification.card
                  : api_url + notification.card
                  : "";
                  const sentDate = new Date(notification.timestamp.seconds * 1000).toLocaleDateString()
                  let redirect = `/user/gifting/giftreceived/?quantity=${quantity}&card=${card}&message=${message.replace(/#/g, "hashhash")}&senderEmail=${senderEmail}&senderName=${senderName}&receiverEmail=${receiverEmail}&receiverName=${receiverName}`
                  if (notification.isSender) {
                    redirect = `/user/gifting/giftsent/?gift=sent&name=${receiverName}&email=${receiverEmail}&date=${sentDate}`
                  }                  // add modal html here
                  $("#globalModal").html(`
                  <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content" style="background: url(/assets/img/GiftingPage/giftModalBg.png); border-radius: 22px; background-size: 100% 100%;">
                    <div class="modal-body">
                      <!-- <button class="modal-close" data-dismiss="modal">&times;</button> -->
                      <div class="text-center">
                        <img src="/assets/img/GiftingPage/giftCardModal.png" alt="" style="max-width:222px; height:auto">
                        <div class="pt-2 pb-4">
                          <p style="
                          font-family: 'Montserrat';
                          font-style: normal;
                          font-weight: 700;
                          font-size: 26px;
                          line-height: 40px;
                          /* or 154% */

                          text-align: center;

                          color: #FFFFFF;" class="mb-0">${body}</p>
                            ${
                              card && card.length
                                ? `<img class="img-fluid my-3" src="${card}" alt="" style="max-width: 265px; width:auto; height: auto">`
                                : ""
                            }

                            <p style="
                            font-family: 'Montserrat';
                            font-style: normal;
                            font-weight: 500;
                            font-size: 24px;
                            line-height: 29px;
                            text-align: center;
                            
                            color: #FFFFFF;" class="py-1">${message}</p>

                            <a href="${redirect}"
                            style="color: white;background: #03313E; width: 140px; text-align: center; border-radius: 5px; font-size: 14px; font-weight: 600;"
                              type="button"
                              data-index="0"
                              class="
                                download-gift-btn
                                btn btn-block
                                my-2
                                mx-auto
                                
                                rounded
                                shadow-sm
                                formButton
                              "
                              style="color: #FFFFFF;"
                            >
                              Open Gift
                            </a>

                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                `);
                  $("#globalModal").modal("show");

                  //   <form action="/user/gifting/redeem" method="POST" style="display: inline-block">
                  //   <input type="hidden" name="email" value="${userEmail}">
                  //   <input type="hidden" name="giftCode" value="${notification.token}">
                  //   <input type="hidden" name="status" value="REJECT">
                  //   <button class="modalBtn px-3 py-1" href="#">Reject</button>
                  // </form>
                } else if (type == "gift") {
                  link = "/user/gifting/#my_gifts";
                } else if (type == "user") {
                  link = "/user#buysgcs";

                  if (title.includes("accepted") && title.includes("gift")) {
                    if (body.includes("accepted") && body.includes("gift")) {
                      link = "/user/gifting/#giftHistory";
                    }
                  } else if (
                    title.includes("rejected") &&
                    title.includes("gift")
                  ) {
                    if (body.includes("rejected") && body.includes("gift")) {
                      link = "/user/gifting/#giftHistory";
                    }
                  }

                  if (title.includes("join") && title.includes("squad")) {
                    if (
                      (body.includes("invited") || body.includes("invites")) &&
                      body.includes("join")
                    ) {
                      link = "/squad";
                    }
                  }
                } else if (type == "admin-request") {
                  link = "/squad";
                } else if (type == "blog") {
                  link = notification.url;
                  target = true;
                } else if (
                  type == "squad" &&
                  notification.squad_id &&
                  notification.squad_id.length &&
                  notification.body.includes("has not been accepted")
                ) {
                  link = `/squad2`;
                } else if (
                  type == "squad" &&
                  notification.squad_id &&
                  notification.squad_id.length
                ) {
                  link = `/squad2/${notification.squad_id}`;
                } else {
                  link = "#";
                }
                $("#notification-box").prepend(`
                <a class="dropdown-item d-flex align-items-center" ${
                  target ? "target=_blank" : ""
                } href=${link}>
                  <div>
                      <div class="small text-gray-500">
                          ${notification.title}
                      </div>
                      <span class="font-weight-bold text-dark" style="white-space: normal;">
                          ${notification.body}
                      </span>
                      <div class="small text-gray-500">
                          ${date}
                      </div>
                  </div>
                </a>
                <hr>
              `);
              }
            }
            if (change.type === "removed") {
              console.log("removed : ", change.doc.data());
            }
          });
        });
    } catch (error) {
      console.log("Error adding event listener to notification : ", error);
    }

    $("#alertsDropdown").on("click", async function (el) {
      try {
        $("#notifications-counter").html("");
        if (pendingExist) {
          modifyFlag = true;
          await readAllNotifications(userEmail);
          notificationCount = 0;
          modifyFlag = false;
        }
      } catch (error) {
        console.log("Error reading notifications");
        modifyFlag = false;
      }
    });
  }
});