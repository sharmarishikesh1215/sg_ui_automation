const getCountries = async () => {
    const countries = await axios({
        method: 'GET',
        url: '/general/getCountries'
    });
    return countries.data
}

const getStates = async(country) => {
    const states = await axios({
        method: 'GET',
        url: '/general/getStates/' + country
    });
    return states.data;
}

const getCities = async(state) => {
    const cities = await axios({
        method: 'GET',
        url: '/general/getCities/' + state
    });
    return cities.data;
}