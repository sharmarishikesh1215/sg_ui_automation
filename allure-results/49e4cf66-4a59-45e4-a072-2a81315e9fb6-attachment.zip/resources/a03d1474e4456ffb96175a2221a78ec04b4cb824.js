$(() => {
  const firstLi = $("#firstLi");
  const secondLi = $("#secondLi");
  const thirdLi = $("#thirdLi");
  const fourthLi = $("#fourthLi");
  const fifthLi = $("#fifthLi");
  const txtPassword = $("#password");
  const txtRePassword = $("#re_password");

  // const specialCharRegex = /(?=.*[@#^$!%*?&_+\-<>])/;
  const capitalCharRegex = /^(?=.*[A-Z])/; // previous regex /(?=.*[A-Z])/  /(?=.*?[A-Z])/
  const numberAndUpperCharRegex = /.*?\d/; // previous regex /.*\d/
  const noSpaceRegex = /^\S*$/;
  function hasSpecialCharacter(string) {
    const specialCharacters = [
      "@",
      "#",
      "^",
      "$",
      "!",
      "%",
      "*",
      "?",
      "&",
      "_",
      "+",
      "-",
      "<",
      ">",
    ];

    for (let i = 0; i < string.length; i++) {
      if (specialCharacters.includes(string[i])) {
        return true;
      }
    }

    return false;
  }

  txtPassword.keyup((event) => {
    event.preventDefault();

    const password = txtPassword.val();
    let passFlag = true;
    txtPassword.css("border", "0.5px solid #eb9978");

    if (password && password.length >= 8 && password.length <= 20) {
      firstLi.removeClass("notComplete").addClass("complete");
      passFlag = true && passFlag;
    } else {
      firstLi.removeClass("complete").addClass("notComplete");
      passFlag = false && passFlag;
    }

    if (hasSpecialCharacter(password)) {
      secondLi.removeClass("notComplete").addClass("complete");
      passFlag = true && passFlag;
    } else {
      secondLi.removeClass("complete").addClass("notComplete");
      passFlag = false && passFlag;
    }

    if (capitalCharRegex.test(password)) {
      thirdLi.removeClass("notComplete").addClass("complete");
      passFlag = true && passFlag;
    } else {
      thirdLi.removeClass("complete").addClass("notComplete");
      passFlag = false && passFlag;
    }

    if (numberAndUpperCharRegex.test(password)) {
      fourthLi.removeClass("notComplete").addClass("complete");
      passFlag = true && passFlag;
    } else {
      fourthLi.removeClass("complete").addClass("notComplete");
      passFlag = false && passFlag;
    }

    if (noSpaceRegex.test(password) && password.length) {
      fifthLi.removeClass("notComplete").addClass("complete");
      passFlag = true && passFlag;
    } else {
      fifthLi.removeClass("complete").addClass("notComplete");
      passFlag = false && passFlag;
    }

    if (passFlag) txtPassword.css("border", "0.5px solid green");
  });

  txtRePassword.keyup((event) => {
    event.preventDefault();

    const password = txtPassword.val();
    const rePassword = txtRePassword.val();

    if (password.trim() === rePassword.trim())
      txtRePassword.css("border", "0.5px solid green");
    else txtRePassword.css("border", "0.5px solid #eb9978");
  });
});
